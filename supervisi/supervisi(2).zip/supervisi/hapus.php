<?php 
include "koneksi.php";
$idbarang   = $_POST['idb'];
mysql_query("delete from barang where id='$idbarang';") or die(mysql_error());
echo "<meta http-equiv=\"refresh\" content=\"5;url=index.php/>";
header('location:index.php');
?>