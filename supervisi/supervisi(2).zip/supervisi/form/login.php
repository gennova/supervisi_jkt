<center>
	<form name = "login" method="post" class="login" action="./function/login.php">
		<table>
			<tr>
				<td>Username : </td>
				<td><input type="text" id="user" name="user"></td>
			</tr>
			<tr>
				<td>Password : </td>
				<td><input type="password" id="pass" name="pass"></td>
			</tr>
			<tr>
				<td colspan="2" align="center"><input type='submit' value="Login"></td>
			</tr>
		</table>
	</form>
</center>