<?php
$username="popop";

if($username!="tendy" && $username!="shelvy"){
	echo 'Dibelokkan';
}
?>